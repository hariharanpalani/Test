'use strict';

module.exports = {
  order: require('./lib/routes/order')
};