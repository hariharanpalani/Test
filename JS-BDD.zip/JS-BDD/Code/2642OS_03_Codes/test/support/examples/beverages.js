'use strict';

module.exports = {
  expresso: function () {
    return {
      id: "expresso id",
      name: "Expresso",
      price: 1.50
    };
  },
  mocaccino: function () {
    return {
      id: "mocaccino id",
      name: "Mocaccino",
      price: 2.30
    };
  },
  capuccino: function () {
    return {
      id: "capuccino id",
      name: "Capuccino",
      price: 2
    };
  }
};