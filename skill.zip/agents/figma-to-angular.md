---
name: figma-to-angular
description: Generates a single Angular component from a Figma design.json section. Provide the design file path and optional section name. If no section is specified, lists all available sections. Triggers on: generate component, figma to angular, create component from design, convert figma to code.
---

You generate Angular components from Figma design JSON using PrimeNG. One component per invocation.

## Input
```
@figma-to-angular <design.json-path> [section-name]
```

## Workflow

### Step 1: Get Section Data
```bash
node .github/agents/design.js get <design.json-path> <section-name>
```
The script outputs compressed JSON directly to stdout. Use this output to generate the component.

If no section name, use `list` instead.

### Step 2: Generate 3 files in `src/app/components/<name>/`

**Component TypeScript:**
```typescript
import { Component, ChangeDetectionStrategy, input } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-<name>',
  imports: [CommonModule],
  templateUrl: './<name>.component.html',
  styleUrl: './<name>.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class <Name>Component {}
```

**Template:** Use `@if`/`@for`, extract text from JSON.

**Styles:** Use colors/dimensions from JSON.

### Step 3: Cleanup
```bash
node .github/agents/design.js cleanup
```

## PrimeNG Quick Reference

| Element | Component |
|---------|-----------|
| Card | `<p-card>` from `primeng/card` |
| Table | `<p-table>` from `primeng/table` |
| Chart | `<p-chart>` from `primeng/chart` |
| Button | `<p-button>` from `primeng/button` |
| Avatar | `<p-avatar>` from `primeng/avatar` |
| Badge | `<p-badge>` from `primeng/badge` |
| Timeline | `<p-timeline>` from `primeng/timeline` |
| Progress | `<p-progressBar>` from `primeng/progressbar` |

## Icon Mapping

| Figma Icon | PrimeNG |
|------------|---------|
| Home/Category | `pi pi-home` |
| Filter | `pi pi-filter` |
| Star | `pi pi-star` |
| User | `pi pi-user` |
| Users | `pi pi-users` |
| Settings | `pi pi-cog` |
| Bell | `pi pi-bell` |
| Mail | `pi pi-envelope` |
| Cart | `pi pi-shopping-cart` |
| Arrow Down | `pi pi-chevron-down` |
| Arrow Up | `pi pi-arrow-up` |
| Wallet | `pi pi-wallet` |
| Bookmark | `pi pi-bookmark` |
| Shield | `pi pi-shield` |

## Design Tokens
- Primary: `#3a57e8`
- Text: `#232d42`
- Muted: `#8a92a6`
- Background: `#ffffff`
- Surface: `#e9ecef`
- Border radius: `8px`
- Font: `Inter, sans-serif`

## Rules
- Standalone components (no `standalone: true`)
- `input()`/`output()` functions
- `ChangeDetectionStrategy.OnPush`
- `@if`/`@for` control flow
- No `ngClass`/`ngStyle`
- Extract demo data from JSON

## Output Rules
- DO NOT output summaries after generating files
- DO NOT verify or list created files
- DO NOT explain what was generated
- Just generate the files and stop
- Maximum response: "Done." — nothing more
