const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const command = args[0];
const designPath = args[1];
const sectionQuery = args[2];

const AGENTS_DIR = __dirname;
const ROOT_DIR = path.resolve(AGENTS_DIR, '../..');
const TMP_DIR = path.join(ROOT_DIR, '.tmp');

function showError(msg) {
  console.error(`Error: ${msg}`);
  console.error('\nUsage:');
  console.error('  node .github/agents/design.js list <design.json>');
  console.error('  node .github/agents/design.js get <design.json> <section-name>');
  console.error('  node .github/agents/design.js cleanup');
  process.exit(1);
}

function loadDesign(filePath) {
  const resolved = path.isAbsolute(filePath)
    ? filePath
    : path.resolve(ROOT_DIR, filePath);
  if (!fs.existsSync(resolved)) {
    showError(`Design file not found: ${resolved}`);
  }
  return JSON.parse(fs.readFileSync(resolved, 'utf-8'));
}

function findAllFrames(node, currentPath = []) {
  const results = [];
  if (node.children) {
    node.children.forEach((child, index) => {
      if (child.type === 'FRAME' && child.name) {
        results.push({
          name: child.name,
          path: [...currentPath, index],
          size: Buffer.byteLength(JSON.stringify(child)),
        });
        results.push(...findAllFrames(child, [...currentPath, index]));
      }
    });
  }
  return results;
}

function findFrame(frames, query) {
  const q = query.toLowerCase().replace(/[-_\s]+/g, ' ').trim();

  let match = frames.find(f => f.name.toLowerCase() === q);
  if (match) return match;

  match = frames.find(f => f.name.toLowerCase().startsWith(q));
  if (match) return match;

  match = frames.find(f => f.name.toLowerCase().includes(q));
  if (match) return match;

  const words = q.split(' ');
  match = frames.find(f => {
    const name = f.name.toLowerCase();
    return words.every(w => name.includes(w));
  });
  return match || null;
}

function listSections(designPath) {
  const data = loadDesign(designPath);
  const root = Array.isArray(data) ? data[0] : data.data ? data.data[0] : data;
  const frames = findAllFrames(root);

  console.log(`Design: ${designPath}`);
  console.log(`Sections:\n`);
  frames.forEach(f => {
    const depth = f.path.length - 1;
    const indent = '  '.repeat(depth);
    const sizeKB = (f.size / 1024).toFixed(1);
    console.log(`${indent}${f.name.padEnd(30)} ${sizeKB} KB`);
  });
}

function compressNode(node) {
  if (node === null || typeof node !== 'object') return node;

  if (Array.isArray(node)) {
    return node.map(compressNode);
  }

  const compressed = {};
  const keepFields = ['name', 'type', 'content', 'children', 'width', 'height',
    'backgroundColor', 'color', 'fontSize', 'fontName', 'fontWeight',
    'layoutMode', 'itemSpacing', 'paddingLeft', 'paddingRight', 'paddingTop', 'paddingBottom',
    'cornerRadius', 'strokeColor', 'strokeWeight', 'asset', 'objectFit',
    'primaryAxisAlignItems', 'counterAxisAlignItems'];

  for (const key of keepFields) {
    if (node[key] !== undefined) {
      compressed[key] = node[key];
    }
  }

  if (node.fontName && node.fontName.style) {
    compressed.fontWeight = node.fontName.style;
  }

  if (node.children && Array.isArray(node.children)) {
    compressed.children = node.children.map(compressNode);
  }

  return compressed;
}

function extractSection(designPath, sectionQuery) {
  if (!sectionQuery) {
    showError('Section name is required');
  }

  const data = loadDesign(designPath);
  const root = Array.isArray(data) ? data[0] : data.data ? data.data[0] : data;
  const frames = findAllFrames(root);
  const matched = findFrame(frames, sectionQuery);

  if (!matched) {
    console.error(`Section matching "${sectionQuery}" not found.\n`);
    console.error('Available sections:\n');
    frames.filter(f => f.path.length === 1).forEach(f => {
      console.error(`  ${f.name.padEnd(30)} ${(f.size / 1024).toFixed(1)} KB`);
    });
    process.exit(1);
  }

  let sectionData = root;
  for (const idx of matched.path) {
    sectionData = sectionData.children[idx];
  }

  const compressed = compressNode(sectionData);

  const originalSize = (matched.size / 1024).toFixed(1);
  const compressedSize = (Buffer.byteLength(JSON.stringify(compressed)) / 1024).toFixed(1);

  console.log(`=== SECTION: ${matched.name} (${compressedSize} KB, was ${originalSize} KB) ===`);
  console.log(JSON.stringify(compressed));
}

function cleanup() {
  if (fs.existsSync(TMP_DIR)) {
    fs.rmSync(TMP_DIR, { recursive: true });
  }
  console.log(JSON.stringify({ status: 'ok', message: 'Cleaned up .tmp' }));
}

if (!command) {
  showError('Command is required (list, extract, cleanup)');
}

switch (command) {
  case 'list':
    if (!designPath) showError('Design file path is required');
    listSections(designPath);
    break;
  case 'get':
    if (!designPath) showError('Design file path is required');
    extractSection(designPath, sectionQuery);
    break;
  case 'cleanup':
    cleanup();
    break;
  default:
    showError(`Unknown command: ${command}`);
}
