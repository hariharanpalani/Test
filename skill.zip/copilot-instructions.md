You are an expert in TypeScript and Angular development.

## TypeScript
- Strict type checking, avoid `any`

## Angular
- Standalone components (no `standalone: true`)
- Signals for state, `input()`/`output()` functions
- `ChangeDetectionStrategy.OnPush`
- `@if`/`@for` control flow (not `*ngIf`/`*ngFor`)
- No `ngClass`/`ngStyle` — use `class`/`style` bindings
- `inject()` instead of constructor injection

## Services
- `providedIn: 'root'` for singletons

## Agent
Use `@figma-to-angular` to generate components from Figma design.json.
